
#' Daily code
#'
#' This is the version 1.0 code for daily use.
#'
#' @docType package
#' @name FanCodeV1-package
#' @aliases FanCodeV1
NULL
